﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace ApplicazioneOrologio
{
    public partial class Form1 : Form
    {
        private Stopwatch stopwatch;
        private int totalSeconds;
        public Form1()
        {
            InitializeComponent();
        }
        int hour, minute, second;
        string alarmHour;
        string alarmMinute;



        private void button1_Click_1(object sender, EventArgs e)
        {

                alarmHour = comboBoxOra.Text;
                alarmMinute =comboBoxMinuto.Text;


        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            second = DateTime.Now.Second;
            minute = DateTime.Now.Minute;
            hour = DateTime.Now.Hour;
            label2.Text = hour.ToString();
            label3.Text = minute.ToString();
            label4.Text = second.ToString();
            Suona_Sveglia();



        }

        private void buttonAggiorna_Click(object sender, EventArgs e)
        {
            //Isole Midway -11
            //Hawaii - 10
            //Alaska - 9
            //Los Angeles -8
            //Denver - 7
            //Chicaho - 6
            //New York -5
            //Santiago - 4
            //Brasile - 3
            //Fernando de Noronha - 2
            //Isole di Capo Verde -1Londra + 0
            //Parigi + 1
            //Istanbul + 2
            //Mosca + 3
            //Abu Dhabi +4
            //Islamabad + 5
            //Dacca + 6
            //Bangkok + 7
            //Pechino + 8
            //Tokyo + 9
            //Sydeny + 10
            //Nuova Caledonia +11
            //Fiji + 12
            if (comboBoxFuso.SelectedItem.ToString() == "Isole Midway -11")
            {
                second = DateTime.Now.Second;
                minute = DateTime.Now.Minute;
                hour = DateTime.Now.Hour - 11;
                label2.Text = hour.ToString();
                label3.Text = minute.ToString();
                label4.Text = second.ToString();
            }


        }

        void Suona_Sveglia()
        {

                if (alarmHour== hour.ToString() && alarmMinute== minute.ToString() && second.ToString() == "0")
                {
                    axWindowsMediaPlayer1.URL = "C:\\Users\\surface\\Desktop\\ApplicazioneOrologio\\sveglia.m4a";
                ;

            }
            
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            this.buttonStop2.Enabled = false;
            
            stopwatch = new Stopwatch();

            timer1.Start();
            for(int i=0;i<24;i++)
            {
                comboBoxOra.Items.Add(i);
            }

            for (int j = 0; j < 60; j++)
            {
                comboBoxMinuto.Items.Add(j);
                comboBoxMinuti2.Items.Add(j);
                comboBoxSec.Items.Add(j);

            }

            this.comboBoxMinuti2.SelectedIndex = 0;
            this.comboBoxSec.SelectedIndex = 0;
        }


        private void buttonStart_Click(object sender, EventArgs e)
        {
            stopwatch.Start();
        }


        private void buttonPausa_Click(object sender, EventArgs e)
        {
            stopwatch.Stop();
        }

        private void buttonStart2_Click(object sender, EventArgs e)
        {
            this.buttonStart2.Enabled = false;
            this.buttonStop2.Enabled = true;
            int minutes = int.Parse(this.comboBoxMinuti2.SelectedItem.ToString());
            int seconds = int.Parse(this.comboBoxSec.SelectedItem.ToString());

            totalSeconds = (minutes * 60) + seconds;

            this.timer3.Enabled = true;

        }

        private void buttonStop2_Click(object sender, EventArgs e)
        {
            this.buttonStop2.Enabled = false;
            this.buttonStart2.Enabled = true;

            totalSeconds = 0;
            this.timer3.Enabled = false;

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (totalSeconds>0)
            {
                totalSeconds--;
                int minutes = totalSeconds / 60;
                int seconds = totalSeconds - (minutes * 60);
                this.label17.Text = minutes.ToString() + ":" + seconds.ToString();

            }
            else
            {
                this.timer3.Stop();
                MessageBox.Show("TEMPO SCADUTO");
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            stopwatch.Reset();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.label14.Text = string.Format("{0:hh\\:mm\\:ss\\:fff}", stopwatch.Elapsed);
        }
    }
}
