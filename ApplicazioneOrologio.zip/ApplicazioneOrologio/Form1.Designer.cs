﻿
namespace ApplicazioneOrologio
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSveglia = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxMinuto = new System.Windows.Forms.ComboBox();
            this.comboBoxOra = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBoxFuso = new System.Windows.Forms.ComboBox();
            this.buttonAggiorna = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonPausa = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.comboBoxMinuti2 = new System.Windows.Forms.ComboBox();
            this.comboBoxSec = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.buttonStart2 = new System.Windows.Forms.Button();
            this.buttonStop2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(1204, 175);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(201, 251);
            this.axWindowsMediaPlayer1.TabIndex = 6;
            this.axWindowsMediaPlayer1.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(-9, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(836, 942);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.buttonAggiorna);
            this.tabPage1.Controls.Add(this.comboBoxFuso);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(8, 39);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(820, 895);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "OROLOGIO";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.buttonSveglia);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.comboBoxMinuto);
            this.tabPage2.Controls.Add(this.comboBoxOra);
            this.tabPage2.Location = new System.Drawing.Point(8, 39);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(820, 895);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SVEGLIA";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(210, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(311, 91);
            this.label7.TabIndex = 27;
            this.label7.Text = "OROLOGIO:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(355, 228);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 91);
            this.label11.TabIndex = 26;
            this.label11.Text = ":";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(552, 238);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 91);
            this.label9.TabIndex = 25;
            this.label9.Text = ":";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(623, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 91);
            this.label4.TabIndex = 19;
            this.label4.Text = "00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(425, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 91);
            this.label3.TabIndex = 18;
            this.label3.Text = "00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(240, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 91);
            this.label2.TabIndex = 17;
            this.label2.Text = "00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(24, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 91);
            this.label1.TabIndex = 16;
            this.label1.Text = "TIME:";
            // 
            // buttonSveglia
            // 
            this.buttonSveglia.Location = new System.Drawing.Point(270, 545);
            this.buttonSveglia.Name = "buttonSveglia";
            this.buttonSveglia.Size = new System.Drawing.Size(251, 202);
            this.buttonSveglia.TabIndex = 29;
            this.buttonSveglia.Text = "IMPOSTA SVEGLIA";
            this.buttonSveglia.UseVisualStyleBackColor = true;
            this.buttonSveglia.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Agency FB", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(171, 392);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 63);
            this.label6.TabIndex = 28;
            this.label6.Text = "MINUTO:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Agency FB", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(203, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 63);
            this.label5.TabIndex = 27;
            this.label5.Text = "ORA:";
            // 
            // comboBoxMinuto
            // 
            this.comboBoxMinuto.FormattingEnabled = true;
            this.comboBoxMinuto.Location = new System.Drawing.Point(408, 421);
            this.comboBoxMinuto.Name = "comboBoxMinuto";
            this.comboBoxMinuto.Size = new System.Drawing.Size(171, 33);
            this.comboBoxMinuto.TabIndex = 26;
            // 
            // comboBoxOra
            // 
            this.comboBoxOra.FormattingEnabled = true;
            this.comboBoxOra.Location = new System.Drawing.Point(408, 276);
            this.comboBoxOra.Name = "comboBoxOra";
            this.comboBoxOra.Size = new System.Drawing.Size(171, 33);
            this.comboBoxOra.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Agency FB", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(203, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(330, 63);
            this.label8.TabIndex = 30;
            this.label8.Text = "IMPOSTA SVEGLIA";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Agency FB", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(218, 485);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(324, 44);
            this.label13.TabIndex = 28;
            this.label13.Text = "SELEZIONA FUSO ORARIO:";
            // 
            // comboBoxFuso
            // 
            this.comboBoxFuso.FormattingEnabled = true;
            this.comboBoxFuso.Items.AddRange(new object[] {
            "Isole Midway -11",
            "Hawaii -10",
            "Alaska -9",
            "Los Angeles -8",
            "Denver -7",
            "Chicaho -6",
            "New York -5",
            "Santiago -4",
            "Brasile -3",
            "Fernando de Noronha -2",
            "Isole di Capo Verde -1",
            "Londra +0",
            "Parigi +1",
            "Istanbul +2",
            "Mosca +3",
            "Abu Dhabi +4",
            "Islamabad +5",
            "Dacca +6",
            "Bangkok +7",
            "Pechino +8",
            "Tokyo +9",
            "Sydeny +10",
            "Nuova Caledonia +11",
            "Fiji +12"});
            this.comboBoxFuso.Location = new System.Drawing.Point(213, 586);
            this.comboBoxFuso.Name = "comboBoxFuso";
            this.comboBoxFuso.Size = new System.Drawing.Size(329, 33);
            this.comboBoxFuso.TabIndex = 29;
            // 
            // buttonAggiorna
            // 
            this.buttonAggiorna.BackColor = System.Drawing.SystemColors.Control;
            this.buttonAggiorna.FlatAppearance.BorderSize = 0;
            this.buttonAggiorna.Location = new System.Drawing.Point(311, 682);
            this.buttonAggiorna.Name = "buttonAggiorna";
            this.buttonAggiorna.Size = new System.Drawing.Size(157, 82);
            this.buttonAggiorna.TabIndex = 30;
            this.buttonAggiorna.Text = "AGGIORNA";
            this.buttonAggiorna.UseVisualStyleBackColor = false;
            this.buttonAggiorna.Click += new System.EventHandler(this.buttonAggiorna_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.buttonReset);
            this.tabPage4.Controls.Add(this.buttonPausa);
            this.tabPage4.Controls.Add(this.buttonStart);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Location = new System.Drawing.Point(8, 39);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(816, 895);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "CRONOMETRO";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.buttonStop2);
            this.tabPage5.Controls.Add(this.buttonStart2);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.comboBoxSec);
            this.tabPage5.Controls.Add(this.comboBoxMinuti2);
            this.tabPage5.Location = new System.Drawing.Point(8, 39);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(820, 895);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "TIMER";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(128, 242);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(502, 115);
            this.label14.TabIndex = 0;
            this.label14.Text = "00:00:00.000";
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(27, 460);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(197, 220);
            this.buttonStart.TabIndex = 1;
            this.buttonStart.Text = "START\r\nRIPRENDI";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonPausa
            // 
            this.buttonPausa.Location = new System.Drawing.Point(275, 466);
            this.buttonPausa.Name = "buttonPausa";
            this.buttonPausa.Size = new System.Drawing.Size(197, 214);
            this.buttonPausa.TabIndex = 2;
            this.buttonPausa.Text = "PAUSA";
            this.buttonPausa.UseVisualStyleBackColor = true;
            this.buttonPausa.Click += new System.EventHandler(this.buttonPausa_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(537, 466);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(197, 214);
            this.buttonReset.TabIndex = 3;
            this.buttonReset.Text = "RESET";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // comboBoxMinuti2
            // 
            this.comboBoxMinuti2.FormattingEnabled = true;
            this.comboBoxMinuti2.Location = new System.Drawing.Point(111, 227);
            this.comboBoxMinuti2.Name = "comboBoxMinuti2";
            this.comboBoxMinuti2.Size = new System.Drawing.Size(215, 33);
            this.comboBoxMinuti2.TabIndex = 0;
            // 
            // comboBoxSec
            // 
            this.comboBoxSec.FormattingEnabled = true;
            this.comboBoxSec.Location = new System.Drawing.Point(490, 227);
            this.comboBoxSec.Name = "comboBoxSec";
            this.comboBoxSec.Size = new System.Drawing.Size(210, 33);
            this.comboBoxSec.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(172, 189);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 25);
            this.label15.TabIndex = 2;
            this.label15.Text = "MINUTI:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(547, 189);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(112, 25);
            this.label16.TabIndex = 3;
            this.label16.Text = "SECONDI:";
            // 
            // buttonStart2
            // 
            this.buttonStart2.Location = new System.Drawing.Point(111, 556);
            this.buttonStart2.Name = "buttonStart2";
            this.buttonStart2.Size = new System.Drawing.Size(235, 212);
            this.buttonStart2.TabIndex = 4;
            this.buttonStart2.Text = "START";
            this.buttonStart2.UseVisualStyleBackColor = true;
            this.buttonStart2.Click += new System.EventHandler(this.buttonStart2_Click);
            // 
            // buttonStop2
            // 
            this.buttonStop2.Location = new System.Drawing.Point(410, 556);
            this.buttonStop2.Name = "buttonStop2";
            this.buttonStop2.Size = new System.Drawing.Size(235, 212);
            this.buttonStop2.TabIndex = 5;
            this.buttonStop2.Text = "STOP";
            this.buttonStop2.UseVisualStyleBackColor = true;
            this.buttonStop2.Click += new System.EventHandler(this.buttonStop2_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(292, 338);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(244, 115);
            this.label17.TabIndex = 6;
            this.label17.Text = "00:00";
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Agency FB", 19.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(245, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(262, 62);
            this.label18.TabIndex = 4;
            this.label18.Text = "CRONOMETRO";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Agency FB", 19.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(331, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(128, 62);
            this.label19.TabIndex = 7;
            this.label19.Text = "TIMER";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(256, 797);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(307, 25);
            this.label10.TabIndex = 31;
            this.label10.Text = "NON ANCORA FUNZIONANTE";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(817, 932);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "OROLOGIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonSveglia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxMinuto;
        private System.Windows.Forms.ComboBox comboBoxOra;
        private System.Windows.Forms.ComboBox comboBoxFuso;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonAggiorna;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonPausa;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxSec;
        private System.Windows.Forms.ComboBox comboBoxMinuti2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button buttonStop2;
        private System.Windows.Forms.Button buttonStart2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label10;
    }
}

